Install instructions are at:  http://www.chilkatsoft.com/installPhpWindows.asp 
Reference Documentation: http://www.chilkatsoft.com/refdoc/php.asp
Sample Code: http://www.example-code.com/php/default.asp
Chilkat Blog: http://www.cknotes.com/
Purchase/Prices: http://www.chilkatsoft.com/purchase2.asp
